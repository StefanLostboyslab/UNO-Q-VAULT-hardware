#include <Arduino_RouterBridge.h>
#include <Arduino_LED_Matrix.h>
#include <ArduinoGraphics.h>

Arduino_LED_Matrix matrix;

// Default text when the Arduino first powers on
std::string currentText = "AWAITING SYNC";

void setup() {
  matrix.begin();
  Bridge.begin();
  
  // Register the listener to catch the Python transmission
  Bridge.provide("scroll_text", scroll_text);
}

void loop() {
  // Draw the scrolling marquee (This function blocks until the text finishes scrolling once, then loops)
  matrix.beginDraw();
  matrix.stroke(0xFFFFFFFF);
  matrix.textScrollSpeed(80); // Adjust this later if it's too fast/slow
  matrix.textFont(Font_4x6);
  matrix.beginText(0, 1, 0xFFFFFF);
  
  matrix.print("   "); // Padding so it enters screen smoothly
  matrix.print(currentText.c_str());
  matrix.print("   "); // Padding so it exits screen smoothly
  
  matrix.endText(SCROLL_LEFT);
  matrix.endDraw();
}

// Flawlessly intercepts the pure String directly from Python
void scroll_text(String msg) {
  currentText = std::string(msg.c_str());
}
