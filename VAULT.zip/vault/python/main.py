from arduino.app_bricks.web_ui import WebUI
from arduino.app_utils import App, Bridge, Logger

logger = Logger("vault-matrix")
ui = WebUI()

def update_status(payload: dict):
    msg = payload.get('text', 'SYNC ERROR')
    
    # Flawlessly push the raw String directly over the Bridge!
    Bridge.call("scroll_text", msg)
    return {'ok': True}

# Changed to the flat path!
ui.expose_api('POST', '/matrix', update_status)
App.run()
